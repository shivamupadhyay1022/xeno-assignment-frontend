import React from 'react'

function Signup() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-light-gray">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-3xl font-semibold text-center text-deep-teal mb-6">
          Welcome Back
        </h2>

        {/* Email Input */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Name
          </label>
          <input
            type="text"
            id="name"
            placeholder="Enter your name"
            className="w-full p-3 border border-light-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-light-sky-blue"
          />
        </div>
        {/* Email Input */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            type="email"
            id="email"
            placeholder="Enter your email"
            className="w-full p-3 border border-light-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-light-sky-blue"
          />
        </div>

        {/* Password Input */}
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
            Password
          </label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            className="w-full p-3 border border-light-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-light-sky-blue"
          />
        </div>

        {/* Login Button */}
        <button className="w-full bg-mint-green text-black py-3 rounded-lg font-semibold hover:bg-light-sky-blue transition">
          Sign Up
        </button>

        {/* Additional Links */}
        <div className="flex justify-between mt-4 text-sm text-gray-600">
          <a href="#" className="hover:underline">
            Log In
          </a>
        </div>
      </div>
    </div>
  )
}

export default Signup