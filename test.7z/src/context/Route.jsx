const Route = ({ path, component }) => {
    const Component = component;
    return <Component />;
  };
  
  export default Route;
  